<?php
	include('database/db_config.php');

	$id=$_GET['product_id'];

	$pname=$_POST['product_name'];
	$pcat=$_POST['category'];
	$pprice=$_POST['price'];

	$update_product_sql="UPDATE menu SET category_id='$pcat', prod_name='$pname', price='$pprice' WHERE menu_id='$id'";
	$connection->query($update_product_sql);

	header('location:product_view.php');
?>